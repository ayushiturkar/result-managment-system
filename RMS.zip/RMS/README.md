# Student Result Management System

video demo - https://youtu.be/tm0XTuFnzx8

### How do I get set up? ###

* Install XAMP
* Add the database file 

### contact ###
projectworldsofficial@gmail.com

more projects website - https://projectworlds.in


